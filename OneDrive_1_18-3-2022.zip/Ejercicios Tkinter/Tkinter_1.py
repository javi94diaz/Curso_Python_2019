# Crear una ventana vacia

import tkinter as tk
root=tk.Tk()

root.mainloop()